#!/usr/bin/env python3
"""
Poodle Jump - Game Configuration GUI (Advanced Version with Scrollbars)

Requirements:
-------------
- Python 3.7+
- Pillow library (install with: pip install pillow)
- Assets must be in: ../Engine/assets/images/
    • Acceptable formats: .bmp
    • Required files:
        - enemy_blob_red.bmp
        - enemy_blob_blue.bmp
        - platform_red.bmp
        - platform_green.bmp
        - platform_blue.bmp
- This script saves to:
    ../Engine/assets/images/game_config.json
"""

import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import json
import os
import copy

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.abspath(os.path.join("..", "Engine", "assets", "images"))
ENGINE_DIR = os.path.abspath(os.path.join("..", "Engine"))
ASSETS_REL_DIR = './' + os.path.relpath(ASSETS_DIR, ENGINE_DIR)

# Scrollable frame wrapper
class ScrollableFrame(ttk.Frame):
    def __init__(self, container, *args, **kwargs):
        super().__init__(container, *args, **kwargs)
        canvas = tk.Canvas(self)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        self.scrollable_frame = ttk.Frame(canvas)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

# Each enemy or platform entry
class EntityFrame(tk.Frame):
    def __init__(self, parent, image_dict, title, fields, confirm_callback, default_key):
        super().__init__(parent)
        self.image_dict = image_dict
        self.fields = fields
        self.confirm_callback = confirm_callback
        self.config(relief="groove", borderwidth=2, padx=5, pady=5)

        ttk.Label(self, text=f"{title} Sprite:").grid(row=0, column=0, sticky='w')
        self.sprite_var = tk.StringVar(value=default_key)
        self.sprite_dropdown = ttk.OptionMenu(self, self.sprite_var, self.sprite_var.get(),
                                              *image_dict.keys(), command=self.update_image)
        self.sprite_dropdown.grid(row=0, column=1)

        self.image_label = ttk.Label(self)
        self.image_label.grid(row=1, column=0, columnspan=2)
        self.update_image()

        self.scale_vars = {}
        for i, (label, from_, to_, default) in enumerate(fields, start=2):
            ttk.Label(self, text=f"{label}:").grid(row=i, column=0, sticky='w')
            var = tk.IntVar(value=default)
            scale = tk.Scale(self, from_=from_, to=to_, orient='horizontal', variable=var,
                             command=self.notify_change)
            scale.grid(row=i, column=1)
            self.scale_vars[label] = var

        ttk.Button(self, text="✔ Save to Config", command=self.confirm_callback).grid(
            row=i+1, column=0, columnspan=2, pady=5
        )

    def update_image(self, *_):
        path = os.path.join(ASSETS_DIR, self.image_dict[self.sprite_var.get()])
        try:
            img = Image.open(path)
            img = ImageTk.PhotoImage(img)
            self.image_label.config(image=img, text='')
            self.image_label.image = img
        except Exception as e:
            self.image_label.config(text="[Failed to load image]", image='')

    def get_config(self):
        return {
            "sprite": self.image_dict[self.sprite_var.get()],
            **{k.lower().replace(" ", "_"): v.get() for k, v in self.scale_vars.items()}
        }

    def notify_change(self, *_):
        if hasattr(self, 'on_update'):
            self.on_update()

# Main GUI app
class ConfigApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Poodle Jump Config")
        self.root.geometry("1000x950")

        self.enemy_sprites = {
            "Red Blob": "enemy_blob_red.bmp",
            "Blue Blob": "enemy_blob_blue.bmp"
        }

        self.platform_textures = {
            "Green": "platform_green.bmp",
            "Red": "platform_red.bmp",
            "Blue": "platform_blue.bmp"
        }

        self.player_archetypes = {
            "High Jumper": "jumps_high",
            "Survivor": "survivor",
            "Rocket Boost": "rocket_boost"
        }

        self.confirmed_enemies = []
        self.confirmed_platforms = []

        self.build_gui()

    def build_gui(self):
        main_frame = tk.Frame(self.root)
        main_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        sidebar = tk.Frame(self.root, relief="ridge", borderwidth=2, padx=10, pady=10)
        sidebar.pack(side=tk.RIGHT, fill=tk.Y)
        ttk.Label(sidebar, text="Included in Config").pack()
        self.summary_text = tk.Text(sidebar, width=40, height=30, state='disabled')
        self.summary_text.pack()

        ttk.Label(main_frame, text="Enemies").grid(row=0, column=0, sticky='w')
        self.enemy_scroll = ScrollableFrame(main_frame)
        self.enemy_scroll.grid(row=1, column=0, columnspan=2, sticky='nsew')
        self.enemy_container = self.enemy_scroll.scrollable_frame
        ttk.Button(main_frame, text="+ Add Enemy", command=self.add_enemy).grid(row=2, column=0, pady=5)

        ttk.Label(main_frame, text="Platforms").grid(row=3, column=0, sticky='w')
        self.platform_scroll = ScrollableFrame(main_frame)
        self.platform_scroll.grid(row=4, column=0, columnspan=2, sticky='nsew')
        self.platform_container = self.platform_scroll.scrollable_frame
        ttk.Button(main_frame, text="+ Add Platform", command=self.add_platform).grid(row=5, column=0, pady=5)

#        ttk.Label(main_frame, text="Player Archetype:").grid(row=6, column=0, sticky='w')
#        self.player_var = tk.StringVar(value="High Jumper")
#        ttk.OptionMenu(main_frame, self.player_var, self.player_var.get(),
#                       *self.player_archetypes.keys()).grid(row=6, column=1)

        ttk.Button(main_frame, text="Save Config", command=self.save_config).grid(row=7, column=0, columnspan=2, pady=10)

    def add_enemy(self):
        frame = EntityFrame(
            self.enemy_container,
            self.enemy_sprites,
            "Enemy",
            [("Spawn Rate", 1, 10, 3)],
            lambda f=None, fr=None: self.confirm_entity("enemy", frame),
            "Red Blob"
        )
        frame.on_update = lambda: self.update_summary()
        frame.pack(pady=5, fill='x')

    def add_platform(self):
        frame = EntityFrame(
            self.platform_container,
            self.platform_textures,
            "Platform",
            [("Length", 120, 200, 150), ("Spawn Rate", 1, 10, 5), ("Bounciness", 0, 10, 8)],
            lambda f=None, fr=None: self.confirm_entity("platform", frame),
            "Green"
        )
        frame.on_update = lambda: self.update_summary()
        frame.pack(pady=5, fill='x')

    def confirm_entity(self, type_, frame):
        if type_ == "enemy" and frame not in self.confirmed_enemies:
            self.confirmed_enemies.append(frame)
        elif type_ == "platform" and frame not in self.confirmed_platforms:
            self.confirmed_platforms.append(frame)
        self.update_summary()

    def update_summary(self):
        self.summary_text.config(state='normal')
        self.summary_text.delete(1.0, tk.END)

        for i, f in enumerate(self.confirmed_enemies, 1):
            cfg = f.get_config()
            line = f"Enemy {i}: {os.path.basename(cfg['sprite'])}, Spawn {cfg['spawn_rate']}\n"
            self.summary_text.insert(tk.END, line)

        for i, f in enumerate(self.confirmed_platforms, 1):
            cfg = f.get_config()
            line = f"Platform {i}: {os.path.basename(cfg['sprite'])}, Length {cfg['length']}, Spawn Rate {cfg['spawn_rate']}, Bounce {cfg['bounciness']}\n"
            self.summary_text.insert(tk.END, line)

        self.summary_text.config(state='disabled')

    def save_config(self):
        config = {
            "enemies": [f.get_config() for f in self.confirmed_enemies],
            "platforms": [f.get_config() for f in self.confirmed_platforms]
        }
        default_path = os.path.join(ASSETS_DIR, "default_game_config.json")

        with open(default_path, 'r') as f:
            default_data = json.load(f)
        
        enemy_base = default_data["spawner"]["enemies"][0]
        platform_base = default_data["spawner"]["platforms"][0]

        save_path = os.path.join(ASSETS_DIR, "game_config.json")
        with open(save_path, 'r') as f:
            data = json.load(f)
        
        new_enemies = []
        for i, new_config in enumerate(config["enemies"]):
            new_enemy = copy.deepcopy(enemy_base)
            new_enemy["sprite"] = os.path.join(ASSETS_REL_DIR, new_config["sprite"])
            new_enemy["spawn_rate"] = new_config["spawn_rate"] 
            new_enemies.append(new_enemy)
    
        new_enemies.extend(default_data["spawner"]["enemies"])
        data["spawner"]["enemies"] = new_enemies;
        
        # platform
        new_platforms = []
        for i, new_config in enumerate(config["platforms"]):
            new_platform = copy.deepcopy(platform_base)
            new_platform["sprite"] = os.path.join(ASSETS_REL_DIR, new_config["sprite"]) 
            new_platform["spawn_rate"] = new_config["spawn_rate"] 
            new_platform["size"]["width"] = new_config["length"] 
            new_platform["bounce_factor"] = new_config["bounciness"] 
            new_platforms.append(new_platform)
    
        new_platforms.extend(default_data["spawner"]["platforms"])
        data["spawner"]["platforms"] = new_platforms;

        with open(save_path, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"Config saved to {save_path}")

# Entry point
if __name__ == "__main__":
    root = tk.Tk()
    app = ConfigApp(root)
    root.mainloop()
